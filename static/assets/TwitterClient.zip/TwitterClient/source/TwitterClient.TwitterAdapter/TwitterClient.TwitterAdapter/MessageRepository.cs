﻿using System.Collections.Generic;
using TwitterClient.Contracts.DomainObjects;
using TwitterClient.Contracts.TwitterAdapter;
using Twitterizer.Framework;

namespace TwitterClient.TwitterAdapter {
    public class MessageRepository : IMessageRepository
    {
        public IList<Message> GetMessages(TwitterConfig config) {
            Twitter twitterService = GetTwitterService(config);
            return MapToMessages(twitterService.Status.FriendsTimeline());
        }

        public void PostMessage(TwitterConfig config, string content) {
            Twitter twitterService = GetTwitterService(config);
            twitterService.Status.Update(content);
        }

        private Twitter GetTwitterService(TwitterConfig config) {
            return new Twitter(config.Login, config.Password);
        }

        private IList<Message> MapToMessages(TwitterStatusCollection statusCol) {
            IList<Message> liste = new List<Message>();
            foreach (TwitterStatus status in statusCol) {
                Message message = new Message();
                message.Content = status.Text;
                message.Date = status.Created;
                message.Username = status.TwitterUser.UserName;
                liste.Add(message);
            }
            return liste;
        }
    }
}