﻿using Aztec.StupidDB;
using TwitterClient.Contracts.DomainObjects;
using TwitterClient.Contracts.StupidDBAdapter;

namespace TwitterClient.StupidDBAdapter
{
    public class ConfigRepository : IConfigRepository
    {
        private readonly StupidDB m_stupidDB;

        public ConfigRepository() {
            m_stupidDB = new StupidDB("TwitterClient");
        }

        public void SaveConfig(TwitterConfig config) {
            m_stupidDB.Put("General", "Config", config);
        }

        public TwitterConfig LoadConfig() {
            return m_stupidDB.GetObject<TwitterConfig>("General", "Config");
        }
    }
}
