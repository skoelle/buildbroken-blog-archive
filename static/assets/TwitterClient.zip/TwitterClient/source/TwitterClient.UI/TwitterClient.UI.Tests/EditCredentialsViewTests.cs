﻿using NUnit.Framework;
using Rhino.Mocks;
using TwitterClient.UI.Model;
using TwitterClient.UI.View;

namespace TwitterClient.UI.Tests
{
    [TestFixture]
    public class EditCredentialsViewTests
    {
        private IEditCredentialsModel m_model;

        [SetUp]
        public void Init() {
            m_model = MockRepository.GenerateStub<IEditCredentialsModel>();
        }

        [Test]
        public void Display_FuelltDieTextareaUsername() {
            m_model.Username = "login";

            EditCredentialsView view = new EditCredentialsView(m_model);
            view.Display();

            Assert.AreEqual("login", view.txtUsername.Text);
        }

        [Test]
        public void Display_FuelltDieTextareaPassword()
        {
            m_model.Password = "pass";

            EditCredentialsView view = new EditCredentialsView(m_model);
            view.Display();

            //wie abfragen?
        }
    }
}
