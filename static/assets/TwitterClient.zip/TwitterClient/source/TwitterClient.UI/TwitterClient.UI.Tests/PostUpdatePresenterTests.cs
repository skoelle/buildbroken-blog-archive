﻿using System;
using NUnit.Framework;
using Rhino.Mocks;
using TwitterClient.Contracts.MessageService;
using TwitterClient.UI.Model;
using TwitterClient.UI.Presenter;
using TwitterClient.UI.View;

namespace TwitterClient.UI.Tests
{
    [TestFixture]
    public class PostUpdatePresenterTests
    {
        private IPostUpdateModel m_model;
        private IPostUpdateView m_view;
        private IMessageService m_messageService;

        [SetUp]
        public void Init() {
            m_model = MockRepository.GenerateStub<IPostUpdateModel>();
            m_view = MockRepository.GenerateStub<IPostUpdateView>();
            m_messageService = MockRepository.GenerateStub<IMessageService>();
        }

        [Test]
        public void Instanzierung_ZeigtViewAn() {
            new PostUpdatePresenter(m_model, m_view, m_messageService);
            m_view.AssertWasCalled(a=>a.Show());
        }

        [Test]
        public void Instanzierung_FuegeEventsHinzu() {
            PostUpdatePresenter presenter = new PostUpdatePresenter(m_model, m_view, m_messageService);
            m_view.AssertWasCalled(a => a.SendButtonClicked += presenter.ViewSendButtonClicked);
        }

        [Test]
        public void ViewSendButtonClicked_SendetUpdateAusModelUeberMessageService()
        {
            string updatetext = "my update on twitter";
            m_model.Text = updatetext;

            PostUpdatePresenter presenter = new PostUpdatePresenter(m_model, m_view, m_messageService);
            presenter.ViewSendButtonClicked(null, null);
            m_messageService.AssertWasCalled(a=>a.Post(updatetext));
        }

        [Test]
        public void ViewSendButtonClicked_ZuLangerTextCatchExceptionUndZeigtMessageBoxAn()
        {
            string updatetext = new string('x', 150);
            m_model.Text = updatetext;
            m_messageService.Expect(a => a.Post(updatetext)).Throw(new ArgumentException());
            PostUpdatePresenter presenter = new PostUpdatePresenter(m_model, m_view, m_messageService);
            presenter.ViewSendButtonClicked(null, null);
            m_view.AssertWasCalled(a => a.ShowMessageBox(null), o=>o.IgnoreArguments());
        }

        [Test]
        public void ViewSendButtonClicked_ViewWirdGeschlossen()
        {
            PostUpdatePresenter presenter = new PostUpdatePresenter(m_model, m_view, m_messageService);
            presenter.ViewSendButtonClicked(null, null);
            m_view.AssertWasCalled(a => a.Close());
        }
    }
}
