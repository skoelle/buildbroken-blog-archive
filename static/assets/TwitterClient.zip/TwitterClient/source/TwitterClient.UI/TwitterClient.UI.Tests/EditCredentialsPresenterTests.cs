﻿using NUnit.Framework;
using Rhino.Mocks;
using TwitterClient.Contracts.DomainObjects;
using TwitterClient.Contracts.MessageService;
using TwitterClient.UI.Model;
using TwitterClient.UI.Presenter;
using TwitterClient.UI.View;

namespace TwitterClient.UI.Tests
{
    [TestFixture]
    public class EditCredentialsPresenterTests
    {
        private IEditCredentialsModel m_model;
        private IEditCredentialsView m_view;
        private IMessageService m_messageService;

        [SetUp]
        public void Init() {
            m_model = MockRepository.GenerateStub<IEditCredentialsModel>();
            m_view = MockRepository.GenerateStub<IEditCredentialsView>();
            m_messageService = MockRepository.GenerateStub<IMessageService>();
        }
        
        [Test]
        public void Instanzierung_ZeigtViewAn() {
            new EditCredentialsPresenter(m_model, m_view, m_messageService);
            m_view.AssertWasCalled(a=>a.Display());
        }

        [Test]
        public void Instanzierung_FuegeEventsHinzu() {
            EditCredentialsPresenter presenter = new EditCredentialsPresenter(m_model, m_view, m_messageService);
            m_view.AssertWasCalled(a => a.SaveButtonClicked += presenter.ViewSaveButtonClicked);
        }

        [Test]
        public void Instanzierung_RuftKonfigurationAb()
        {
            new EditCredentialsPresenter(m_model, m_view, m_messageService);
            m_messageService.AssertWasCalled(a => a.GetCredentials());
        }

        [Test]
        public void Instanzierung_FuelltModel()
        {
            TwitterConfig config = new TwitterConfig() {Login = "user", Password = "pass"};
            m_messageService.Expect(a => a.GetCredentials()).Return(config);
            new EditCredentialsPresenter(m_model, m_view, m_messageService);

            Assert.AreEqual(config.Login, m_model.Username);
            Assert.AreEqual(config.Password, m_model.Password);
        }

        [Test]
        public void SaveButtonClicked_ConfigAusModelWirdGespeichert()
        {
            string login = "login";
            string pass = "pass";

            EditCredentialsPresenter presenter = new EditCredentialsPresenter(m_model, m_view, m_messageService);
            m_model.Username = login;
            m_model.Password = pass;
            presenter.ViewSaveButtonClicked(null, null);

            m_messageService.AssertWasCalled(a=>a.SetCredentials(Arg<TwitterConfig>.Matches(b=>b.Login==login || b.Password==pass)));
        }

        [Test]
        public void SaveButtonClicked_SchliesstView() {
            EditCredentialsPresenter presenter = new EditCredentialsPresenter(m_model, m_view, m_messageService);
            presenter.ViewSaveButtonClicked(null, null);
            m_view.AssertWasCalled(a=>a.Close());
        }
    }
}
