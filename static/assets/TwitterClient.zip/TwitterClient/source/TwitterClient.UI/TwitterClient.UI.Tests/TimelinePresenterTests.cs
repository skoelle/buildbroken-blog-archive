﻿using System;
using System.Collections.Generic;
using NUnit.Framework;
using Rhino.Mocks;
using TwitterClient.Contracts.DomainObjects;
using TwitterClient.Contracts.MessageService;
using TwitterClient.UI.Model;
using TwitterClient.UI.Presenter;
using TwitterClient.UI.View;

namespace TwitterClient.UI.Tests
{
    [TestFixture]
    public class TimelinePresenterTests
    {
        private ITimelineModel m_model;
        private ITimelineView m_view;
        private IMessageService m_messageService;
        private IPresenterFactory m_presenterFactory;

        [SetUp]
        public void Init() {
            m_model = MockRepository.GenerateStub<ITimelineModel>();
            m_view = MockRepository.GenerateStub<ITimelineView>();
            m_messageService = MockRepository.GenerateStub<IMessageService>();
            m_presenterFactory = MockRepository.GenerateStub<IPresenterFactory>();
        }

        [Test]
        public void Instanzierung_ZeigtViewAn() {
            m_messageService.Expect(a => a.List()).Return(GetDemoMessageListe());
            new TimelinePresenter(m_model, m_view, m_messageService, m_presenterFactory);
            m_view.AssertWasCalled(a=>a.Show());
        }

        [Test]
        public void Instanzierung_FuegeEventsHinzu() {
            m_messageService.Expect(a => a.List()).Return(GetDemoMessageListe());
            TimelinePresenter presenter = new TimelinePresenter(m_model, m_view, m_messageService, m_presenterFactory);
            m_view.AssertWasCalled(a => a.CloseButtonClicked += presenter.ViewCloseButtonClicked);
            m_view.AssertWasCalled(a => a.ConfigButtonClicked += presenter.ViewConfigButtonClicked);
            m_view.AssertWasCalled(a => a.RefreshButtonClicked += presenter.ViewRefreshButtonClicked);
            m_view.AssertWasCalled(a => a.StatusUpdateButtonClicked += presenter.ViewStatusUpdateButtonClicked);
        }

        [Test]
        public void Instanzierung_LaedtMessages()
        {
            m_messageService.Expect(a => a.List()).Return(GetDemoMessageListe());
            new TimelinePresenter(m_model, m_view, m_messageService, m_presenterFactory);
            m_messageService.AssertWasCalled(a => a.List());
        }

        [Test]
        public void Instanzierung_FuelltModel()
        {
            m_messageService.Expect(a => a.List()).Return(GetDemoMessageListe());
            new TimelinePresenter(m_model, m_view, m_messageService, m_presenterFactory);

            Assert.AreEqual(2, m_model.Messages.Count);
            Assert.AreEqual(GetDemoMessageListe()[0].Content, m_model.Messages[0].Content);
            Assert.AreEqual(GetDemoMessageListe()[1].Content, m_model.Messages[1].Content);
        }

        [Test]
        public void Instanzierung_ModelWirdAufDerViewAusgegeben()
        {
            m_messageService.Expect(a => a.List()).Return(GetDemoMessageListe());
            new TimelinePresenter(m_model, m_view, m_messageService, m_presenterFactory);
            m_view.AssertWasCalled(a => a.FillView());            
        }

        [Test]
        public void ViewConfigButtonClicked_InstanziertPresenter()
        {
            m_messageService.Expect(a => a.List()).Return(GetDemoMessageListe()).Repeat.Twice();
            TimelinePresenter presenter = new TimelinePresenter(m_model, m_view, m_messageService, m_presenterFactory);
            presenter.ViewConfigButtonClicked(null, null);
            m_presenterFactory.AssertWasCalled(a => a.Create<EditCredentialsPresenter>());
        }

        [Test]
        public void ViewRefreshButtonClicked_HoltZweimalVomMessageServiceAb()
        {
            m_messageService.Expect(a => a.List()).Return(GetDemoMessageListe()).Repeat.Twice();
            TimelinePresenter presenter = new TimelinePresenter(m_model, m_view, m_messageService, m_presenterFactory);
            presenter.ViewRefreshButtonClicked(null, null);
            m_messageService.AssertWasCalled(a=>a.List(), o=>o.Repeat.Twice());
        }

        [Test]
        public void ViewStatusUpdateButtonClicked_InstanziertPresenter()
        {
            m_messageService.Expect(a => a.List()).Return(GetDemoMessageListe());
            TimelinePresenter presenter = new TimelinePresenter(m_model, m_view, m_messageService, m_presenterFactory);
            presenter.ViewStatusUpdateButtonClicked(null, null);
            m_presenterFactory.AssertWasCalled(a => a.Create<PostUpdatePresenter>());
        }

        private IList<Message> GetDemoMessageListe()
        {
            IList<Message> liste = new List<Message>();
            liste.Add(new Message { Content = "1" });
            liste.Add(new Message { Content = "2" });
            return liste;
        }

    }
}
