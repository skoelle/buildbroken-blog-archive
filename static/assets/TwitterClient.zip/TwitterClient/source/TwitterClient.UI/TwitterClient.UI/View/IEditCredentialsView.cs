using System;

namespace TwitterClient.UI.View {
    public interface IEditCredentialsView {
        void Display();
        void Close();
        event EventHandler<EventArgs> SaveButtonClicked;
    }
}