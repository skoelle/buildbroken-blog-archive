using System;

namespace TwitterClient.UI.View {
    public interface ITimelineView {
        void Show();
        void FillView();
        event EventHandler<EventArgs> CloseButtonClicked;
        event EventHandler<EventArgs> ConfigButtonClicked;
        event EventHandler<EventArgs> RefreshButtonClicked;
        event EventHandler<EventArgs> StatusUpdateButtonClicked;

    }
}