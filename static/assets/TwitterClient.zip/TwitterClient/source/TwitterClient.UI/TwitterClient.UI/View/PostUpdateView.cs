﻿using System;
using System.Windows.Forms;
using TwitterClient.UI.Model;

namespace TwitterClient.UI.View {
    public partial class PostUpdateView : Form, IPostUpdateView
    {
        private readonly IPostUpdateModel m_postUpdateModel;

        public PostUpdateView(IPostUpdateModel postUpdateModel) {
            m_postUpdateModel = postUpdateModel;
            InitializeComponent();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUpdate.Text)) {
                MessageBox.Show("Sie haben keinen Text eingegeben.");
                return;
            }
            m_postUpdateModel.Text = txtUpdate.Text;
            SendButtonClicked(this, e);
        }

        public event EventHandler<EventArgs> SendButtonClicked;
        public void ShowMessageBox(string text) {
            MessageBox.Show(text);
        }
    }
}