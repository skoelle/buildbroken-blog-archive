﻿namespace TwitterClient.UI.View {
    partial class TimelineView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("");
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnConfig = new System.Windows.Forms.Button();
            this.lstPublicTimeline = new System.Windows.Forms.ListView();
            this.Datum = new System.Windows.Forms.ColumnHeader();
            this.User = new System.Windows.Forms.ColumnHeader();
            this.Message = new System.Windows.Forms.ColumnHeader();
            this.SuspendLayout();
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(926, 12);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(113, 23);
            this.btnRefresh.TabIndex = 1;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(926, 42);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(113, 23);
            this.btnUpdate.TabIndex = 2;
            this.btnUpdate.Text = "Status Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnConfig
            // 
            this.btnConfig.Location = new System.Drawing.Point(926, 72);
            this.btnConfig.Name = "btnConfig";
            this.btnConfig.Size = new System.Drawing.Size(113, 23);
            this.btnConfig.TabIndex = 3;
            this.btnConfig.Text = "Konfiguration";
            this.btnConfig.UseVisualStyleBackColor = true;
            this.btnConfig.Click += new System.EventHandler(this.btnConfig_Click);
            // 
            // lstPublicTimeline
            // 
            this.lstPublicTimeline.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Datum,
            this.User,
            this.Message});
            this.lstPublicTimeline.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1});
            this.lstPublicTimeline.Location = new System.Drawing.Point(12, 12);
            this.lstPublicTimeline.Name = "lstPublicTimeline";
            this.lstPublicTimeline.Size = new System.Drawing.Size(902, 568);
            this.lstPublicTimeline.TabIndex = 0;
            this.lstPublicTimeline.UseCompatibleStateImageBehavior = false;
            this.lstPublicTimeline.View = System.Windows.Forms.View.Details;
            // 
            // Datum
            // 
            this.Datum.Text = "Datum";
            this.Datum.Width = 120;
            // 
            // User
            // 
            this.User.Text = "User";
            this.User.Width = 120;
            // 
            // Message
            // 
            this.Message.Text = "Message";
            this.Message.Width = 500;
            // 
            // TimelineView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1047, 592);
            this.Controls.Add(this.btnConfig);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.lstPublicTimeline);
            this.Name = "TimelineView";
            this.Text = "TwitterClient";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnConfig;
        private System.Windows.Forms.ListView lstPublicTimeline;
        private System.Windows.Forms.ColumnHeader Datum;
        private System.Windows.Forms.ColumnHeader User;
        private System.Windows.Forms.ColumnHeader Message;
    }
}