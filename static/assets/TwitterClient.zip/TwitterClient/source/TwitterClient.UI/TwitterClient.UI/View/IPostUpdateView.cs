using System;

namespace TwitterClient.UI.View {
    public interface IPostUpdateView {
        void Show();
        void Close();
        event EventHandler<EventArgs> SendButtonClicked;
        void ShowMessageBox(string text);
    }
}