﻿using System;
using System.Windows.Forms;
using TwitterClient.UI.Model;

namespace TwitterClient.UI.View {
    public partial class EditCredentialsView : Form, IEditCredentialsView
    {
        private readonly IEditCredentialsModel m_editCredentialsModel;

        public EditCredentialsView(IEditCredentialsModel editCredentialsModel) {
            m_editCredentialsModel = editCredentialsModel;
            InitializeComponent();
        }

        public void Display() {
            txtUsername.Text = m_editCredentialsModel.Username;
            txtPassword.Text = m_editCredentialsModel.Password;
            Show();
        }

        public event EventHandler<EventArgs> SaveButtonClicked;

        private void btnSave_Click(object sender, EventArgs e)
        {
            m_editCredentialsModel.Username = txtUsername.Text;
            m_editCredentialsModel.Password = txtPassword.Text;
            SaveButtonClicked(this, e);
        }
    }
}