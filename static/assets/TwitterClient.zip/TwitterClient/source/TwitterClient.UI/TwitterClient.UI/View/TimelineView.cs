﻿using System;
using System.Windows.Forms;
using TwitterClient.UI.Model;

namespace TwitterClient.UI.View {
    public partial class TimelineView : Form, ITimelineView
    {
        private readonly ITimelineModel m_timelineModel;

        public TimelineView(ITimelineModel timelineModel) {
            m_timelineModel = timelineModel;
            InitializeComponent();

            Closed += delegate { CloseButtonClicked(this, new EventArgs()); }; 

        }

        public void FillView() {
            lstPublicTimeline.Items.Clear();
            foreach (MessageModel messageModel in m_timelineModel.Messages) {
                lstPublicTimeline.Items.Add(GetListViewItem(messageModel));
            }
        }

        private ListViewItem GetListViewItem(MessageModel messageModel) {
            string[] values = new string[3];
            values[0] = messageModel.Date.ToString();
            values[1] = messageModel.Username;
            values[2] = messageModel.Content;
            return new ListViewItem(values);
        }

        public event EventHandler<EventArgs> CloseButtonClicked;
        public event EventHandler<EventArgs> ConfigButtonClicked;
        public event EventHandler<EventArgs> RefreshButtonClicked;
        public event EventHandler<EventArgs> StatusUpdateButtonClicked;

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshButtonClicked(this, e);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            StatusUpdateButtonClicked(this, e);
        }

        private void btnConfig_Click(object sender, EventArgs e)
        {
            ConfigButtonClicked(this, e);
        }

    }
}