using TwitterClient.UI.Presenter;

namespace TwitterClient.UI {
    public interface IPresenterFactory {
        T Create<T>() where T:IPresenter;
    }
}