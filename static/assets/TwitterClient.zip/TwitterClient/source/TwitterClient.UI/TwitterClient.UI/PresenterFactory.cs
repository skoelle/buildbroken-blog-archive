using TwitterClient.UI.Presenter;

namespace TwitterClient.UI {
    public class PresenterFactory : IPresenterFactory
    {
        public T Create<T>() where T : IPresenter {
            return Container.Resolve<T>();
        }
    }
}