﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using TwitterClient.Contracts.MessageService;
using TwitterClient.UI.Model;
using TwitterClient.UI.View;
using Message=TwitterClient.Contracts.DomainObjects.Message;

namespace TwitterClient.UI.Presenter
{
    public class TimelinePresenter : IPresenter
    {
        private readonly ITimelineModel m_timelineModel;
        private readonly ITimelineView m_timelineView;
        private readonly IMessageService m_messageService;
        private readonly IPresenterFactory m_presenterFactory;

        public TimelinePresenter(ITimelineModel timelineModel, ITimelineView timelineView, IMessageService messageService, IPresenterFactory presenterFactory) {
            m_timelineModel = timelineModel;
            m_timelineView = timelineView;
            m_messageService = messageService;
            m_presenterFactory = presenterFactory;
            
            UpdateModelWithMessageService();
            
            m_timelineView.Show();
            m_timelineView.CloseButtonClicked += ViewCloseButtonClicked;
            m_timelineView.ConfigButtonClicked += ViewConfigButtonClicked;
            m_timelineView.RefreshButtonClicked += ViewRefreshButtonClicked;
            m_timelineView.StatusUpdateButtonClicked += ViewStatusUpdateButtonClicked;
        }

        public void ViewCloseButtonClicked(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void ViewConfigButtonClicked(object sender, EventArgs e)
        {
            m_presenterFactory.Create<EditCredentialsPresenter>();
            UpdateModelWithMessageService();
        }

        public void ViewStatusUpdateButtonClicked(object sender, EventArgs e)
        {
            m_presenterFactory.Create<PostUpdatePresenter>();
        }

        public void ViewRefreshButtonClicked(object sender, EventArgs e)
        {
            UpdateModelWithMessageService();
        }


        private void UpdateModelWithMessageService() {
            IList<MessageModel> liste = new List<MessageModel>();
            IList<Message> ausgeleseneListe = m_messageService.List();
            foreach (Message message in ausgeleseneListe) {
                MessageModel messageModel = new MessageModel();
                messageModel.Content = message.Content;
                messageModel.Date = message.Date;
                messageModel.Username = message.Username;
                liste.Add(messageModel);
            }
            m_timelineModel.Messages = liste;
            m_timelineView.FillView();
        }
    }
}
