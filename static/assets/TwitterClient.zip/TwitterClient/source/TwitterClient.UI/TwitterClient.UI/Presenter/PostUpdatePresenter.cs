﻿using System;
using TwitterClient.Contracts.MessageService;
using TwitterClient.UI.Model;
using TwitterClient.UI.View;

namespace TwitterClient.UI.Presenter
{
    public class PostUpdatePresenter : IPresenter
    {
        private readonly IPostUpdateModel m_postUpdateModel;
        private readonly IPostUpdateView m_postUpdateView;
        private readonly IMessageService m_messageService;

        public PostUpdatePresenter(IPostUpdateModel postUpdateModel, IPostUpdateView postUpdateView, IMessageService messageService) {
            m_postUpdateModel = postUpdateModel;
            m_postUpdateView = postUpdateView;
            m_messageService = messageService;

            m_postUpdateView.SendButtonClicked+=ViewSendButtonClicked;

            m_postUpdateView.Show();
        }

        public void ViewSendButtonClicked(object sender, EventArgs e) {
            try {
                m_messageService.Post(m_postUpdateModel.Text);
            } catch(ArgumentException) {
                m_postUpdateView.ShowMessageBox("Das Update konnte nicht uebermittelt werden.");
            }
            m_postUpdateView.Close();
        }
    }
}
