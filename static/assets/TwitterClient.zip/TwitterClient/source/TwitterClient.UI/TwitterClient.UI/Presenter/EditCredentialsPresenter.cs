﻿using System;
using TwitterClient.Contracts.DomainObjects;
using TwitterClient.Contracts.MessageService;
using TwitterClient.UI.Model;
using TwitterClient.UI.View;

namespace TwitterClient.UI.Presenter
{
    public class EditCredentialsPresenter : IPresenter
    {
        private readonly IEditCredentialsModel m_editCredentialsModel;
        private readonly IEditCredentialsView m_editCredentialsView;
        private readonly IMessageService m_messageService;

        public EditCredentialsPresenter(IEditCredentialsModel editCredentialsModel, IEditCredentialsView editCredentialsView, IMessageService messageService) {
            m_editCredentialsModel = editCredentialsModel;
            m_editCredentialsView = editCredentialsView;
            m_messageService = messageService;

            m_editCredentialsView.SaveButtonClicked += ViewSaveButtonClicked;

            GetKonfigUndFuelleModel();
            m_editCredentialsView.Display();
        }

        private void GetKonfigUndFuelleModel() {
            TwitterConfig config = m_messageService.GetCredentials();
            if (config != null) {
                if (!string.IsNullOrEmpty(config.Login)) m_editCredentialsModel.Username = config.Login;
                if (!string.IsNullOrEmpty(config.Password)) m_editCredentialsModel.Password = config.Password;
            }
        }

        public void ViewSaveButtonClicked(object sender, EventArgs e)
        {
            TwitterConfig config = new TwitterConfig();
            config.Login = m_editCredentialsModel.Username;
            config.Password = m_editCredentialsModel.Password;
            m_messageService.SetCredentials(config);
            m_editCredentialsView.Close();
        }
    }
}
