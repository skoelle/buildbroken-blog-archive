﻿namespace TwitterClient.UI.Presenter
{
    public interface IPresenter
    {
    }
}
