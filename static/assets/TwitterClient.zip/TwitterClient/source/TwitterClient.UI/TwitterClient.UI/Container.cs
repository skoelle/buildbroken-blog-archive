using Castle.Windsor;

namespace TwitterClient.UI {
    public static class Container {
        private static readonly WindsorContainer m_container;
        static Container() {
            m_container  = new WindsorContainer("container.xml");
            m_container.AddComponent<IPresenterFactory, PresenterFactory>();
        }

        public static T Resolve<T>() {
            return m_container.Resolve<T>();
        }
    }
}