﻿namespace TwitterClient.UI.Model
{
    public class PostUpdateModel : IPostUpdateModel
    {
        public string Text { get; set; }
    }
}
