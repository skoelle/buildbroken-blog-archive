using System;

namespace TwitterClient.UI.Model {
    public struct MessageModel {
        public string Content { get; set; }
        public string Username { get; set; }
        public DateTime Date { get; set; }
    }
}