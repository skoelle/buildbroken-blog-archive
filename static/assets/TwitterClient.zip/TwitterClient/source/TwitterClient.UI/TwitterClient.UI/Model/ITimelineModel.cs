﻿using System.Collections.Generic;

namespace TwitterClient.UI.Model
{
    public interface ITimelineModel
    {
        IList<MessageModel> Messages { get; set; }
    }
}
