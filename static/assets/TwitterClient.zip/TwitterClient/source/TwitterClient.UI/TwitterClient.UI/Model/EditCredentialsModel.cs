namespace TwitterClient.UI.Model {
    public class EditCredentialsModel : IEditCredentialsModel {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}