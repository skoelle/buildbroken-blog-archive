﻿namespace TwitterClient.UI.Model
{
    public interface IEditCredentialsModel
    {
        string Username { get; set; }
        string Password { get; set; }
    }
}
