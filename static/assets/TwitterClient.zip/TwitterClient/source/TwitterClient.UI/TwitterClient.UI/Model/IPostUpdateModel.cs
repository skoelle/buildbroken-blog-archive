namespace TwitterClient.UI.Model {
    public interface IPostUpdateModel {
        string Text { get; set; }
    }
}