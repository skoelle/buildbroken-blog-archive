using System.Collections.Generic;

namespace TwitterClient.UI.Model {
    public class TimelineModel : ITimelineModel
    {
        public IList<MessageModel> Messages { get; set; }
    }
}