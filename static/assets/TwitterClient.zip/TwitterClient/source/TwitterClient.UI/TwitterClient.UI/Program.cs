﻿using System;
using System.Windows.Forms;
using TwitterClient.UI.Presenter;

namespace TwitterClient.UI
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Container.Resolve<TimelinePresenter>();
            Application.Run();
        }
    }
}
