﻿using System.Collections.Generic;
using TwitterClient.Contracts.DomainObjects;

namespace TwitterClient.Contracts.TwitterAdapter {
    public interface IMessageRepository
    {
        /// <summary>
        /// Laedt die Friends-Timeline von Twitter
        /// </summary>
        /// <param name="config">Konfigurationsdaten</param>
        /// <returns>Liste von TwitterMessages</returns>
        IList<Message> GetMessages(TwitterConfig config);

        /// <summary>
        /// Setzt ein Statusupdate bei Twitter
        /// </summary>
        /// <param name="config">Konfigurationsdaten</param>
        /// <param name="content">Inhalt des Status</param>
        void PostMessage(TwitterConfig config, string content);
    }
}