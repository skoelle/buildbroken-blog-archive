﻿using System;
using System.Collections.Generic;
using TwitterClient.Contracts.DomainObjects;

namespace TwitterClient.Contracts.MessageService
{
    public interface IMessageService
    {
        /// <summary>
        /// Gibt die Friends-Timeline der hinterlegten Twitteraccount-Daten zurueck
        /// </summary>
        /// <returns></returns>
        IList<Message> List();
        
        /// <summary>
        /// Postet ein Update bei Twitter mit den hinterlegten Twitteraccount-Daten
        /// </summary>
        /// <param name="content">Der Text des Updates bei Twitter</param>
        /// <exception cref="ArgumentException">Wenn ein Update laenger als 140 Zeichen ist.</exception>
        void Post(string content);

        /// <summary>
        /// Speichert die Twitteraccount-Daten ab
        /// </summary>
        /// <param name="config"></param>
        void SetCredentials(TwitterConfig config);

        /// <summary>
        /// Liefert die hinterlegten Twitteraccount-Daten
        /// </summary>
        /// <returns></returns>
        TwitterConfig GetCredentials();
    }
}
