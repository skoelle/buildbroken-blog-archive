﻿using TwitterClient.Contracts.DomainObjects;

namespace TwitterClient.Contracts.StupidDBAdapter
{
    public interface IConfigRepository
    {
        /// <summary>
        /// Speichert die Konfiguration in der StupidDB
        /// </summary>
        /// <param name="config"></param>
        void SaveConfig(TwitterConfig config);

        /// <summary>
        /// Laedt die Konfiguration aus der StupidDB
        /// </summary>
        /// <returns></returns>
        TwitterConfig LoadConfig();
    }
}
