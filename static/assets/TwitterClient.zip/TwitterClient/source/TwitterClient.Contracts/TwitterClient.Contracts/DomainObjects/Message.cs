﻿using System;

namespace TwitterClient.Contracts.DomainObjects
{
    /// <summary>
    /// Twitternachricht
    /// </summary>
    public class Message
    {
        public string Username { get; set; }
        public string Content { get; set; }
        public DateTime Date { get; set; }
    }
}
