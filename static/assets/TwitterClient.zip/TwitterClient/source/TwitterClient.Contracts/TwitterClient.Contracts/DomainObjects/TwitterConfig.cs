﻿namespace TwitterClient.Contracts.DomainObjects
{
    /// <summary>
    /// Logindaten des Twitteraccounts
    /// </summary>
    public class TwitterConfig
    {
        public string Login { get; set; }
        public string Password { get; set; }
    }
}
