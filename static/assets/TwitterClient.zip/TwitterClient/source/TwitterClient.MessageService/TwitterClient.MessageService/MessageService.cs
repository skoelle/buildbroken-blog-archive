﻿using System;
using System.Collections.Generic;
using TwitterClient.Contracts.DomainObjects;
using TwitterClient.Contracts.MessageService;
using TwitterClient.Contracts.StupidDBAdapter;
using TwitterClient.Contracts.TwitterAdapter;

namespace TwitterClient.MessageService
{
    public class MessageService : IMessageService
    {
        private readonly IMessageRepository m_messageRepository;
        private readonly IConfigRepository m_configRepository;
        private TwitterConfig m_config;

        public MessageService(IMessageRepository messageRepository, IConfigRepository configRepository) {
            m_messageRepository = messageRepository;
            m_configRepository = configRepository;
            m_config = GetCredentials();
        }

        public IList<Message> List() {
            if (string.IsNullOrEmpty(m_config.Login) || string.IsNullOrEmpty(m_config.Password)) return new List<Message>();
            return m_messageRepository.GetMessages(m_config);
        }

        public void Post(string content) {
            if (string.IsNullOrEmpty(m_config.Login) || string.IsNullOrEmpty(m_config.Password)) return;
            if (content==null) return;
            if (string.IsNullOrEmpty(content.Trim())) return;
            if (content.Length > 140) throw new ArgumentException("Der Text darf nicht laenger als 140 Zeichen sein.");
            m_messageRepository.PostMessage(m_config, content);
        }

        public void SetCredentials(TwitterConfig config) {
            if (config==null) return;
            if (string.IsNullOrEmpty(config.Login) || string.IsNullOrEmpty(config.Password)) return;
            m_configRepository.SaveConfig(config);
            m_config = config;
        }

        public TwitterConfig GetCredentials() {
            return m_configRepository.LoadConfig() ?? new TwitterConfig();
        }
    }
}
