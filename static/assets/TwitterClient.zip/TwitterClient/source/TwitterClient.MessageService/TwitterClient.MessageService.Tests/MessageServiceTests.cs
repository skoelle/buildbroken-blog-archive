﻿using System;
using System.Collections.Generic;
using NUnit.Framework;
using Rhino.Mocks;
using TwitterClient.Contracts.DomainObjects;
using TwitterClient.Contracts.StupidDBAdapter;
using TwitterClient.Contracts.TwitterAdapter;

namespace TwitterClient.MessageService.Tests
{
    [TestFixture]
    public class MessageServiceTests
    {
        private IMessageRepository m_messageRepository;
        private IConfigRepository m_configRepository;

        [SetUp]
        public void Init() {
            m_messageRepository = MockRepository.GenerateStub<IMessageRepository>();
            m_configRepository = MockRepository.GenerateStub<IConfigRepository>();
        }

        [Test]
        public void InstanzierungLaedtAktuelleKonfiguration() {
            m_configRepository.Expect(a => a.LoadConfig()).Return(new TwitterConfig());
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            m_configRepository.AssertWasCalled(a=>a.LoadConfig());
        }

        [Test]
        public void GetCredentials_NormaleWerte_RueckgabeDerWerte() {
            m_configRepository.Expect(a => a.LoadConfig()).Return(new TwitterConfig() {Login="user", Password="pass"}).Repeat.Twice();
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            TwitterConfig config = messageService.GetCredentials();
            Assert.AreEqual("user", config.Login);
            Assert.AreEqual("pass", config.Password);
        }

        [Test]
        public void GetCredentials_NullVonAdapter_LeereConfigWirdZurueckgegeben() {
            m_configRepository.Expect(a => a.LoadConfig()).Return(null).Repeat.Twice();
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            TwitterConfig config = messageService.GetCredentials();
            Assert.IsNotNull(config);
        }

        [Test]
        public void SetCredentials_NormaleWerte_LeereConfigWirdZurueckgegeben()
        {
            TwitterConfig neueConfig = new TwitterConfig() {Login = "userNEU", Password = "passNEU"};

            m_configRepository.Expect(a => a.LoadConfig()).Return(new TwitterConfig());
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            messageService.SetCredentials(neueConfig);

            m_configRepository.AssertWasCalled(a=>a.SaveConfig(Arg<TwitterConfig>.Matches(b=>b.Login==neueConfig.Login && b.Password==neueConfig.Password)));
        }

        [Test]
        public void SetCredentials_NullWirdUebergeben_KeinSaveWirdAufgerufen() {
            TwitterConfig neueConfig = null;

            m_configRepository.Expect(a => a.LoadConfig()).Return(new TwitterConfig());
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            messageService.SetCredentials(neueConfig);

            m_configRepository.AssertWasNotCalled(a => a.SaveConfig(null), o=>o.IgnoreArguments());
        }

        [Test]
        public void SetCredentials_LeererLogin_KeinSaveWirdAufgerufen()
        {
            TwitterConfig neueConfig = new TwitterConfig() { Login = "", Password = "passNEU" };

            m_configRepository.Expect(a => a.LoadConfig()).Return(new TwitterConfig());
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            messageService.SetCredentials(neueConfig);

            m_configRepository.AssertWasNotCalled(a => a.SaveConfig(null), o => o.IgnoreArguments());
        }

        [Test]
        public void SetCredentials_LeeresPassword_KeinSaveWirdAufgerufen()
        {
            TwitterConfig neueConfig = new TwitterConfig() { Login = "userNEU", Password = "" };

            m_configRepository.Expect(a => a.LoadConfig()).Return(new TwitterConfig());
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            messageService.SetCredentials(neueConfig);

            m_configRepository.AssertWasNotCalled(a => a.SaveConfig(null), o => o.IgnoreArguments());
        }

        [Test]
        public void List_NormalerLogin_TwitterAdapterWirdAufgerufen() {
            TwitterConfig config = new TwitterConfig() { Login = "user", Password = "pass" };
            m_configRepository.Expect(a => a.LoadConfig()).Return(config);
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            messageService.List();

            m_messageRepository.AssertWasCalled(a => a.GetMessages(Arg<TwitterConfig>.Matches(b => b.Login == config.Login && b.Password == config.Password)));
        }

        [Test]
        public void List_NormalerLogin_NachrichtenVonTwitterAdapterWerdenZurueckgegeben()
        {
            TwitterConfig config = new TwitterConfig() { Login = "user", Password = "pass" };
            IList<Message> ausgangsliste = new List<Message>();
            ausgangsliste.Add(new Message() { Content = "1" });
            ausgangsliste.Add(new Message() { Content = "2" });
            m_messageRepository.Expect(a => a.GetMessages(Arg<TwitterConfig>.Matches(b => b.Login == config.Login && b.Password == config.Password))).Return(ausgangsliste);

            m_configRepository.Expect(a => a.LoadConfig()).Return(config);
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            IList<Message> rueckgabeliste = messageService.List();

            Assert.AreEqual(ausgangsliste.Count, rueckgabeliste.Count);
            Assert.AreEqual(ausgangsliste[0].Content, rueckgabeliste[0].Content);
            Assert.AreEqual(ausgangsliste[1].Content, rueckgabeliste[1].Content);
        }

        [Test]
        public void List_LeereConfig_TwitterAdapterWirdNichtAufgerufen()
        {
            TwitterConfig config = new TwitterConfig();
            m_configRepository.Expect(a => a.LoadConfig()).Return(config);
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            messageService.List();

            m_messageRepository.AssertWasNotCalled(a => a.GetMessages(null), o=>o.IgnoreArguments());
        }

        [Test]
        public void List_LeereConfig_LeereListeKommtZurueck()
        {
            TwitterConfig config = new TwitterConfig();
            m_configRepository.Expect(a => a.LoadConfig()).Return(config);
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            IList<Message> liste = messageService.List();

            Assert.IsNotNull(liste);
            Assert.AreEqual(0, liste.Count);
        }

        [Test]
        public void Post_NormalerLoginUndStatus_TwitterAdapterWirdAufgerufen() {
            TwitterConfig config = new TwitterConfig() { Login = "user", Password = "pass" };
            m_configRepository.Expect(a => a.LoadConfig()).Return(config);
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            messageService.Post("Text");

            m_messageRepository.AssertWasCalled(a => a.PostMessage(Arg<TwitterConfig>.Matches(b => b.Login == config.Login && b.Password == config.Password), Arg<string>.Matches(c=>c=="Text")));
        }

        [Test]
        public void Post_LeererLogin_TwitterAdapterWirdNichtAufgerufen()
        {
            TwitterConfig config = new TwitterConfig();
            m_configRepository.Expect(a => a.LoadConfig()).Return(config);
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            messageService.Post("Text");

            m_messageRepository.AssertWasNotCalled(a => a.PostMessage(null, null), o=>o.IgnoreArguments());
        }

        [Test]
        public void Post_NullAlsUpdateText_TwitterAdapterWirdNichtAufgerufen()
        {
            TwitterConfig config = new TwitterConfig() { Login = "user", Password = "pass" };
            m_configRepository.Expect(a => a.LoadConfig()).Return(config);
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            messageService.Post(null);

            m_messageRepository.AssertWasNotCalled(a => a.PostMessage(null, null), o => o.IgnoreArguments());
        }

        [Test]
        public void Post_LeerenUpdateText_TwitterAdapterWirdNichtAufgerufen()
        {
            TwitterConfig config = new TwitterConfig() { Login = "user", Password = "pass" };
            m_configRepository.Expect(a => a.LoadConfig()).Return(config);
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            messageService.Post("");

            m_messageRepository.AssertWasNotCalled(a => a.PostMessage(null, null), o => o.IgnoreArguments());
        }

        [Test]
        public void Post_NurLeerzeichenUpdateText_TwitterAdapterWirdNichtAufgerufen()
        {
            TwitterConfig config = new TwitterConfig() { Login = "user", Password = "pass" };
            m_configRepository.Expect(a => a.LoadConfig()).Return(config);
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);
            messageService.Post("   ");

            m_messageRepository.AssertWasNotCalled(a => a.PostMessage(null, null), o => o.IgnoreArguments());
        }

        [Test]
        public void Post_UpdateTextMit140Zeichen_KannGeradeNochGespeichertWerden()
        {
            string updateString = new string('x', 140);

            TwitterConfig config = new TwitterConfig() { Login = "user", Password = "pass" };
            m_configRepository.Expect(a => a.LoadConfig()).Return(config);
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);

            messageService.Post(updateString);

            m_messageRepository.AssertWasCalled(a => a.PostMessage(Arg<TwitterConfig>.Matches(b => b.Login == config.Login && b.Password == config.Password), Arg<string>.Matches(c => c == updateString)));
        }

        [Test]
        public void Post_UpdateTextLaengerAls140Zeichen_ArgumentExceptionWirdGeworfen()
        {
            TwitterConfig config = new TwitterConfig() { Login = "user", Password = "pass" };
            m_configRepository.Expect(a => a.LoadConfig()).Return(config);
            MessageService messageService = new MessageService(m_messageRepository, m_configRepository);

            Assert.Throws<ArgumentException>(() => messageService.Post(new string('x', 141)));
            m_messageRepository.AssertWasNotCalled(a => a.PostMessage(null, null), o => o.IgnoreArguments());
        }
    }
}
