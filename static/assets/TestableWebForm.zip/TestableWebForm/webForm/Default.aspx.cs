﻿using System;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using framework.Testable.Web.UI;

namespace TestableWebForm
{
    public class DefaultPage : System.Web.UI.Page
    {

        #region Controls
        public HtmlForm Formular;
        public TextBox Value1 = new TextBox();
        public TextBox Value2 = new TextBox();
        public Label Result = new Label();
        public Button Submit = new Button();
        #endregion

        private IPage m_page;
        public void SetTestableObjects( IPage page )
        {
            m_page = page;
        }

        public void Page_Load( object sender, EventArgs e )
        {
            if (m_page == null) m_page = new Page( this );
            int multiple = 1;
            if (!string.IsNullOrEmpty( m_page.Request.GetParamValue( "multiple" ) )) multiple = Convert.ToInt32( m_page.Request.GetParamValue( "multiple" ) );
            if (m_page.IsPostBack)
            {
                Result.Text = ( (Convert.ToInt32( Value1.Text ) + Convert.ToInt32( Value2.Text ))*multiple ).ToString();
            }
        }
    }
}