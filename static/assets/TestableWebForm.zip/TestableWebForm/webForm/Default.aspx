﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="TestableWebForm.DefaultPage" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
<head id="Head1" runat="server">
    <title></title>
</head>
<body>
    <form id="Formular" runat="server">
    <div style="margin-left:10px; margin-top:10px;">
    <h2>Testable WebForm</h2>
    <p>Value 1: <asp:TextBox ID="Value1" runat="server"></asp:TextBox></p>
    <p>Value 2: <asp:TextBox ID="Value2" runat="server"></asp:TextBox></p>
    <p><asp:Button ID="Submit" Text="Calculate" runat="server" /></p>
    <p>Result: <asp:Label ID="Result" runat="server"></asp:Label></p>
    </div>
    </form>
</body>
</html>
