﻿using framework.Testable.Web;
using framework.Testable.Web.UI;
using NUnit.Framework;
using Rhino.Mocks;
using TestableWebForm;

namespace Tests
{
    [TestFixture]
    public class WebFormTests
    {
        private IPage m_page;
        private IHttpRequest m_request;
        private IHttpResponse m_response;
        private DefaultPage m_defaultPage;

        [SetUp]
        public void Init()
        {
            m_page = MockRepository.GenerateStub<IPage>();
            m_request = MockRepository.GenerateStub<IHttpRequest>();
            m_response = MockRepository.GenerateStub<IHttpResponse>();
            m_page.Request = m_request;
            m_page.Response = m_response;
        }

        [Test]
        public void PageLoad_Loading_EmptyFields()
        {
            // Arrange


            // Act
            m_defaultPage = new DefaultPage();
            m_defaultPage.SetTestableObjects(m_page);
            m_defaultPage.Page_Load( null, null );

            // Assert
            Assert.IsEmpty( m_defaultPage.Value1.Text );
            Assert.IsEmpty( m_defaultPage.Value2.Text );
            Assert.IsEmpty(m_defaultPage.Result.Text);
        }

        [Test]
        public void PageLoad_PostBack_ResultIsNotEmpty()
        {
            // Arrange
            const int value1 = 1;
            const int value2 = 2;
            m_page.Expect( a => a.IsPostBack ).Return( true );

            // Act
            m_defaultPage = new DefaultPage();
            m_defaultPage.SetTestableObjects( m_page );
            m_defaultPage.Value1.Text = value1.ToString();
            m_defaultPage.Value2.Text = value2.ToString();
            m_defaultPage.Page_Load( null, null );

            // Assert
            Assert.IsNotEmpty( m_defaultPage.Result.Text );
        }

        [Test]
        public void PageLoad_PostBackWithRequestValue_ResultIsCorrect()
        {
            // Arrange
            const int value1 = 1;
            const int value2 = 2;
            const int value3 = 3;
            m_request.Expect( a => a.GetParamValue( "multiple" ) ).IgnoreArguments().Repeat.Twice().Return( value3.ToString() );
            m_page.Expect( a => a.IsPostBack ).Return( true );

            // Act
            m_defaultPage = new DefaultPage();
            m_defaultPage.SetTestableObjects( m_page );
            m_defaultPage.Value1.Text = value1.ToString();
            m_defaultPage.Value2.Text = value2.ToString();
            m_defaultPage.Page_Load( null, null );

            // Assert
            Assert.IsTrue( m_defaultPage.Result.Text == ( (value1 + value2)*value3 ).ToString() );
        }
    }
}
