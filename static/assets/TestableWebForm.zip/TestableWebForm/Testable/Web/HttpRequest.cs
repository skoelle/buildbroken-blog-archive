﻿using System.Collections.Specialized;

namespace framework.Testable.Web
{
    public interface IHttpRequest
    {
        NameValueCollection Params
        {
            get;
        }

        string this[string name]
        {
            get;
        }

        string GetParamValue(string name);
    }
    public class HttpRequest : IHttpRequest
    {
        private readonly System.Web.UI.Page m_page;

        public HttpRequest( System.Web.UI.Page page )
        {
            m_page = page;
        }

        public NameValueCollection Params
        {
            get
            {
                return m_page.Request.Params;
            }
        }

        public string this[string name]
        {
            get
            {
                return m_page.Request.Params[name];
            }
        }

        public string GetParamValue(string name)
        {
            return (Params == null) ? string.Empty : Params[name];
        }
    }
}
