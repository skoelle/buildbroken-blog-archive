﻿namespace framework.Testable.Web
{
    namespace UI
    {
        public interface IPage
        {
            bool IsPostBack{get;}
            IHttpRequest Request
            {
                get; set;
            }
            IHttpResponse Response
            {
                get; set;
            }
        }

        public class Page : IPage
        {
            private readonly System.Web.UI.Page m_page;
            private IHttpRequest m_request;
            private IHttpResponse m_response;

            public Page( System.Web.UI.Page page )
            {
                m_page = page;
                m_request = new HttpRequest( m_page );
                m_response = new HttpResponse( m_page );
            }

            public bool IsPostBack
            {
                get
                {
                    return m_page.IsPostBack;
                }
            }

            public IHttpRequest Request
            {
                get{ return m_request; }
                set { m_request = value; }
            }

            public IHttpResponse Response
            {
                get{ return m_response; }
                set { m_response = value; }
            }
        }
    }
}
