﻿namespace framework.Testable.Web
{
    public interface IHttpResponse
    {
        void Redirect( string url );
        void Redirect( string url, bool endResponse );
    }

    public class HttpResponse : IHttpResponse
    {
        private readonly System.Web.UI.Page m_page;

        public HttpResponse( System.Web.UI.Page page )
        {
            m_page = page;
        }

        public void Redirect( string url )
        {
            m_page.Response.Redirect( url );
        }

        public void Redirect( string url, bool endResponse )
        {
            m_page.Response.Redirect( url, endResponse );
        }
    }
}
